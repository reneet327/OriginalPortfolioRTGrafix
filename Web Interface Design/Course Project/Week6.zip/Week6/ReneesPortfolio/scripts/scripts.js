// JavaScript Document


function mShiftShow(){
	var mShiftShow = document.getElementById("abtMshift");
	var mShiftImage = document.getElementById("mShiftImage");

	
	mShiftShow.style.display="block";
	
}